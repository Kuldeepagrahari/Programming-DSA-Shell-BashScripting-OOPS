extract_substring() {
    string=$1
    start=$2
    end=$3

    if (( start < 0 || end < 0 || start > ${#string} || end > ${#string} || start > end )); then
        echo "error"
        return 1
    fi

    length=$((end - start + 1))
    echo "${string:$start:$length}"
}

extract_substring "Hello, World!" 0 2