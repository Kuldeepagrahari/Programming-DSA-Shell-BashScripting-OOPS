#Define a function is_prime(n) that takes a positive integer n as input and returns True if n is prime, False otherwise.
#Additionally, create a function print_primes(start, end) that takes two positive 
#integers start and end as input and prints all prime numbers within the range [start, end].

is_prime() {
    n=$1
    if [ $n -lt 2 ]; then
        echo "False"
        return
    fi
    for ((i=2;i*i<=n;i++)); do
        if [ $((n%i)) -eq 0 ]; then
            echo "False"
            return
        fi
    done
    echo "True"
}

print_primes() {
    start=$1
    end=$2
    for ((n=start;n<=end;n++)); do
        if [ $(is_prime $n) = "True" ]; then
            echo $n
        fi
    done
}

read -p "Enter start: " start
read -p "Enter end: " end
print_primes $start $end