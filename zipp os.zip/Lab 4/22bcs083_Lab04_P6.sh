generate_random_numbers() {
    n=$1
    strt=$2
    end=$3
    numbers=()
    for (( i=0; i<n; i++ ))
    do
        numbers[i]=$(( RANDOM % (end - strt + 1 ) + strt ))
    done
    echo ${numbers[@]}
}
calculate_average() {
    numbers=($@)
    sum=0
    for num in ${numbers[@]}
    do
         sum+=num
    done
    average=$(echo $"scale=2; sum / ${#numbers[@]}" | bc)
}
numbers=$(generate_random_numbers 10 1 100)
average=$(calculate_average $numbers)

echo "generated random number: $numbers"
echo "average: $average"
