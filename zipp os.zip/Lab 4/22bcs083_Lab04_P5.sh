# Define a function reverse_number(n) that takes an integer n as input and returns its reversed integer value.

revNum() {

    read -p "Enter a number: " num
    rev=0

    while [ $num -gt 0 ]
    do
        rem=$(( num % 10 ))
        rev=$(( rev * 10 + rem ))
        num=$(( num / 10 ))
    done

    echo $rev
}


revNum