#function count vowels in an input string for upperCase and lowerCase

countVowels() {
    read -p "Enter a string: " str
    str=$(echo $str | tr '[:upper:]' '[:lower:]')
    count=0
    for (( i=0; i<${#str}; i++ ))
    do
        ch=${str:$i:1}
        if [[ $ch == "a" || $ch == "e" || $ch == "i" || $ch == "o" || $ch == "u" ]]
        then
            count=$((count + 1))
        fi
    done
    echo "Number of vowels: $count"
}

countVowels