factorial() {
    if [ $1 -le 1 ]; then
        echo 1
    else
        fact=$(factorial $(( $1 - 1 )))
        echo $(( $1 * fact ))
    fi
}

for (( i=1; i<=10; i++)); do
    factorial $i
done