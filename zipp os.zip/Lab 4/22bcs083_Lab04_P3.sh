#Define a function print_fibonacci(n) that takes a positive integer n as input and prints the Fibonacci series up to the nth term.

printFib() {
    read -p "Enter a number: " n
    a=0
    b=1
    echo "Fibonacci Series: "
    for (( i=0; i<n; i++ ))
    do
        echo -n "$a "
        fn=$((a + b))
        a=$b
        b=$fn
    done
    echo
}

printFib