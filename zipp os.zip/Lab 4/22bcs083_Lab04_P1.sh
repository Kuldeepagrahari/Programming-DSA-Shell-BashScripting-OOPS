#Question 1: Write a function print_squares(n) that takes a positive integer n as input and prints the squares of all numbers from 1 to n.


printSq()
{
    read -p "Enter a number: " num

    for ((i = 1; i <= num; i++))
    do 
        sq=$((i * i))
        echo $sq
    done
}

printSq