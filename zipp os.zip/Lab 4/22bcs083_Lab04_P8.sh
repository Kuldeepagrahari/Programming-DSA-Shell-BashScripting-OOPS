#Define a function print_fibonacci(n) that takes a positive integer n as input and prints the Fibonacci series up to the nth term.

printFib() {
    n=$3
    a=$1
    b=$2
    echo "Fibonacci Series: "
    for (( i=0; i<n; i++ ))
    do
        echo -n "$a "
        fn=$((a + b))
        a=$b
        b=$fn
    done
    echo
}

echo "echo -n "Enter the first two numbers of the Fibonacci series: ""
read a
read b

read -p "Enter a number: " n

printFib $a $b $n