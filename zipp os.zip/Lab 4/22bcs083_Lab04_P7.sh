#Function For Sum Of Even Nums In The Given Range

sumEven()
{
    sum=0
    for (( i=$1; i<=$2; i++ ))
    do
        if [ $((i%2)) -eq 0 ]
        then
            sum=$((sum+i))
        fi
    done
    echo "Sum of Even Numbers in the range $1 to $2 is: $sum"
}

read -p "Enter the start of the range: " start
read -p "Enter the end of the range: " end
sumEven $start $end
