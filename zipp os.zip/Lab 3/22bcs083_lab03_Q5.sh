#!/bin/bash

if [ $# -eq 0 ]; then
    echo "please enter the valid file name"
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "file $1 not exits"
    exit 1
fi

while read -r line; do
    for word in $line; do
        if [[ $word == *@*.* && $word != *@.*.* ]]; then
            echo "$word"
        fi
    done
done < "$1" 

