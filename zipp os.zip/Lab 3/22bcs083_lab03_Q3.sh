#!/bin/bash

echo "Enter the number"
read num

fact=1

for((i=2;i<=num;i++))
{
    fact=$((fact*i))
}
echo "factorial Of the number is : $fact"
