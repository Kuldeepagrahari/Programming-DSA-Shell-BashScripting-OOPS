#!/bin/bash

fun() {
    add=$(echo "$1 + $2" | bc -l)
    subtract=$(echo "$1 - $2" | bc -l)
    multiply=$(echo "$1 * $2" | bc -l)
    divide=$(echo "$1 / $2" | bc -l)

    echo "Addition: $add"
    echo "Subtraction: $subtract"
    echo "Multiplication: $multiply"
    echo "Division: $divide"
}
read -p "enter the first number: " num1
read -p "enter te second number: " num2

fun $num1 $num2
