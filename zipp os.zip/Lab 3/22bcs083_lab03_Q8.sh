#!/bin/bash

threshold=0

while true; do
  cpu_usage=$(top -b -n 1 | grep "%Cpu(s)" | awk '{print $2}' | cut -d. -f1)

  if [ "$cpu_usage" -gt "$threshold" ]; then
    echo "High CPU usage detected! Current CPU usage: $cpu_usage%"
  fi

  sleep 5
done
