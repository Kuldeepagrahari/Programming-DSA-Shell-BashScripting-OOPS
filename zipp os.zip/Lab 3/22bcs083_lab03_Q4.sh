#!/bin/bash
prime() {
    n=$1
    if [ $n -eq 1 ]; then
        echo "$n is not a prime number."
        return
    fi
    for ((i = 2; i < n; i++)); do
        if [ $((n % i)) -eq 0 ]; then
            echo "$n is not a prime number."
            return
        fi
    done

    echo "$n is a prime number."
}

read -p "enter the number: " num
prime $num

