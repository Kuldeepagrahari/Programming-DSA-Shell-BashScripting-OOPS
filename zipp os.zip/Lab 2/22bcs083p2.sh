#!/bin/bash

fun() {
    max=$1

    if [ $2 -gt $max ]; then
        max=$2
    fi

    if [ $3 -gt $max ]; then
        max=$3
    fi

    if [ $4 -gt $max ]; then
        max=$4
    fi

    echo "Maximum number is: $max"
}

read -p "Enter the first number: " num1
read -p "Enter the second number: " num2
read -p "Enter the third number: " num3
read -p "Enter the fourth number: " num4

fun $num1 $num2 $num3 $num4
