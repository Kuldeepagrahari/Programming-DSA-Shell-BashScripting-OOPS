
#!/bin/bash

if [ $# -ne 1 ]
then
    echo "Please provide exactly one argument"
    exit 1
fi

num=$1
rev_num=$(echo $num | rev)
binary_num=""
temp=$num
while [ $temp -gt 0 ]
do
    binary_num=$(($temp % 2))$binary_num
    temp=$(($temp / 2))
done

rev_binary_num=$(echo $binary_num | rev)

if [ $num -eq $rev_num ]
then 
    echo "$num is a palindrome in decimal representation."
else
    echo "$num is not a palindrome in decimal representation."
fi

if [ $binary_num -eq $rev_binary_num ]
then 
    echo "$num is a palindrome in binary representation."
else
    echo "$num is not a palindrome in binary representation."
fi


if [ $num -eq $rev_num ] && [ $binary_num -eq $rev_binary_num ]
then
    echo "$num is a palindrome in both decimal and binary representations."
else
    echo "$num is not a palindrome in both decimal and binary representations."
fi
