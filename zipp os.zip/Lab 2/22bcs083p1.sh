#!/bin/bash

read -p "Enter the first number: " num
read -p "Enter the position: " n
echo $((num | 1 << n))
