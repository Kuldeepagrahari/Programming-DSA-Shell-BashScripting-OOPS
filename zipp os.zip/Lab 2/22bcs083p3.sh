#!/bin/bash

fun() {
    add=$(echo "$1 + $2" | bc -l)
    subtract=$(echo "$1 - $2" | bc -l)
    multiply=$(echo "$1 * $2" | bc -l)
    divide=$(echo "$1 / $2" | bc -l)

    echo "Addition: $add"
    echo "Subtraction: $subtract"
    echo "Multiplication: $multiply"
    echo "Division: $divide"
}

# Example usage
read -p "Enter the first floating-point number: " num1
read -p "Enter the second floating-point number: " num2

fun $num1 $num2
