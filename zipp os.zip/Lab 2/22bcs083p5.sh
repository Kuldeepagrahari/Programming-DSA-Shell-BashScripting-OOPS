#!/bin/bash

check_string() {
    s=$1
    first=${s:0:1}
    last=${s: -1}

    if [ "$first" = "A" ] && [ "$last" = "Z" ]; then
        echo "The string '$s' starts with 'A' and ends with 'Z'"
    else
        echo "The string '$s' does not starts with 'A' and ends with 'Z'"
    fi
}

read -p "Enter a string: " s
check_string "$s"
