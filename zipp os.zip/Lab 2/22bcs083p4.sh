#!/bin/bash

# Function to check if a number is between 10 and 20 (inclusive)
checkRange() {
    if [ $1 -ge 10 ] && [ $1 -le 20 ]; then
        echo "$1 is between 10 and 20."
    else
        echo "$1 is not between 10 and 20."
    fi
}

read -p "Enter a number: " num
checkRange $num
