#!/bin/bash

read -p "Enter the first integer: " num1
read -p "Enter the second integer: " num2
read -p "Enter the third integer: " num3

if [ $num1 -gt $num2 ]; then
    temp=$num1
    num1=$num2
    num2=$temp
fi

if [ $num2 -gt $num3 ]; then
    temp=$num2
    num2=$num3
    num3=$temp
fi

if [ $num1 -gt $num2 ]; then
    temp=$num1
    num1=$num2
    num2=$temp
fi

echo "Sorted integers in ascending order: $num1, $num2, $num3"
