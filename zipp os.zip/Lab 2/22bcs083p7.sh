#!/bin/bash

read -p "Enter the student's marks: " marks

if [ $marks -ge 90 -a $marks -le 100 ]; then
    grade="A"
elif [ $marks -ge 80 -a $marks -le 89 ]; then
    grade="B"
elif [ $marks -ge 70 -a $marks -le 79 ]; then
    grade="C"
elif [ $marks -ge 60 -a $marks -le 69 ]; then
    grade="D"
else
    grade="F"
fi

echo "The student's grade is: $grade"
